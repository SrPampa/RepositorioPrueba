def formatoSumando(pri,seg):
    resul = pri + seg
    cadena='Primer sumando: {0} segundo sumando: {1}  el Resultado es: {2}'
    print(cadena.format(pri,seg,resul))
    return 
def letraCapital(frase):
    return frase.capitalize()

# formatoSumando(int(input('Dame el primer Sumando')),int(input('\n Dame el segundo sumando ')))

# print(letraCapital(input('Dame una frase : ')))

person = {persona1:{
    'name': 'Alice',
    'gender': 'female'
}, persona2: {
    'name': 'Alice',
    'gender': 'female'
}}

print(f'{"El usuario" if person.persona1.get("gender") == "male" else "La usuaria"} {person.persona1.get("name")} se encuentra en línea’)

