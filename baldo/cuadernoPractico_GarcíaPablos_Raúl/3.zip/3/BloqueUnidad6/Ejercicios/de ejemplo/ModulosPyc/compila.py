import py_compile
py_compile.compile("fibonan.py")