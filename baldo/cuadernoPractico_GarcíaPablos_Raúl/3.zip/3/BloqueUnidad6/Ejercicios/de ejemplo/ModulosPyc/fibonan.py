import  fibo
fibo.fib(1000)
print(dir())