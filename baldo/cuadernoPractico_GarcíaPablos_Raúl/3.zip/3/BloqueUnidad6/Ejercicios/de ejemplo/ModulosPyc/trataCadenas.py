def  caracter(cadena):
    y=[]
    for x in cadena:
        y.append(x)
    return y
        

def longitud(cadena):
    return len(cadena)

def contiene(frase,cadena):
    return (cadena in frase)

def tipo(cadena):
    return(type(cadena))
def extraer(cadena,posI,posF):
    return(cadena[posI:posF])
def mayusculas(cadena):
    return cadena.upper()
def minusculas(cadena):
    return cadena.lower()



cadena = "buenos ddias"
print(caracter(cadena))
print(longitud(cadena))
print(contiene(cadena,"dia"))
print(tipo(cadena))
print(extraer(cadena,2,5))
print(extraer(cadena,5,8))
print(mayusculas(cadena))
print(minusculas(cadena))