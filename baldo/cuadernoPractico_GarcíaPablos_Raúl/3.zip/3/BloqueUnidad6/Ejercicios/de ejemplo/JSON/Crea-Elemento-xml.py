import xml.etree.cElementTree as ET
root = ET.Element("html")
br = ET.SubElement(root,"br")
doc = ET.SubElement(root, "head")
nodo1 = ET.SubElement(doc, "meta", name="nodo")
nodo1.text = "Texto de nodo1"
ET.SubElement(doc, "meta", atributo="algo").text = "texto 2"
body = ET.SubElement(root, "body")
formula = ET.SubElement(body, "form", name="miFormulario")
arbol = ET.ElementTree(root)
arbol.write("prueba.xml")
