import json 
datos = {
    'nombre' : 'Juan Perez',
    'edad' : 18,
    'pais' : 'Panama' 
    } 
with open('datos.json', 'w') as file:
    json.dump(datos, file)
