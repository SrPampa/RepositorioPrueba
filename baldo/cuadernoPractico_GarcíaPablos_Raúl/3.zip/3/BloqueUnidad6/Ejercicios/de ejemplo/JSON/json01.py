import json
data =["NOMBRE", "Ocupación","Sexo"]
data2 = ["Pepe","Minero", "Varón"]
# Fuswionar las dos listas en un diccionario

salida = {data[i]:data2[i] for  i in range(len(data))}
with open("miFichero.json","w") as j:
     json.dump(salida,j)