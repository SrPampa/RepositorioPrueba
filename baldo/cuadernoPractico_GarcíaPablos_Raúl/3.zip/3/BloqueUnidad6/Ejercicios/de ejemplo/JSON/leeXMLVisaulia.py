from xml.dom import minidom
doc = minidom.parse("DatosPaises.xml")
nombre = doc.getElementsByTagName("data")[0]
print("Datos de la ciudad : %s " % nombre.firstChild.data)
ciudad = doc.getElementsByTagName("country")
for ciudades in ciudad:
    sid = ciudades.getAttribute("name")
    rank = ciudades.getElementsByTagName("rank")[0]
    ano = ciudades.getElementsByTagName("year")[0]
    codigo = ciudades.getElementsByTagName("gdppc")[0]
    ciuda = ciudades.getElementsByTagName("neighbor")
    pais = ciudades.getElementsByTagName("neighbor")[0]
    print("\t id: %s " % sid)
    print("\t rank: %s" % rank.firstChild.data)
    print("\t año : %s" % ano.firstChild.data)
    print("\t codigo postal: %s" % codigo.firstChild.data)
 
    for recorre in ciuda:
        pNombre = recorre.getAttribute("name")
        dNombre = recorre.getAttribute("direction")
        print("\t \t Nombre Pais: %s " % pNombre)
        print("\t \t Id nombre: %s " % dNombre)
 
    