import xml.etree.cElementTree as ET
tree = ET.parse('DatosPaises.xml')
# obtjener directamente dla cadena de caracterds
root = ET.fromstring(tree)
# devuelte el tipo de obtjeto leido
print(root)


print(root.tag)
print(root.attrib)
# Recorrer toda la caena