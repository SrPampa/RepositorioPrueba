import json

with open("datos.json","r") as j:
    misdatos = json.load(j)
    print(misdatos)