import datetime
import io

def abrir_log(nombre_log):
    archivo_log = open(nombre_log, "a")
    guardar_log(archivo_log, "Iniciando registro de errores")
    return archivo_log

def guardar_log(archivo_log, mensaje):
    # Obtiene la hora actual en formato de texto
    hora_actual = str(datetime.datetime.now())
    # Guarda la hora actual y el mensaje de error en el archivo
    archivo_log.write(hora_actual+" "+mensaje+"\\n")
    
def cerrar_log(archivo_log):
    guardar_log(archivo_log, "Fin del registro de errores")
    archivo_log.close()

archivo= abrir_log("trabajo.txt")
guardar_log(archivo,"primeros datos")
cerrar_log(archivo)