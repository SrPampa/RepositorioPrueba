import re

frase = "Yo creo que la gente, cuando es inteligente y completamente normal, no debe pretender el ser rara y extraña, porque llega al absurdo inventado"

def contarPalabras(frase):
    lista = frase.split(" ")
    numPalabras = len(lista)
    print(f"La frase contiene {numPalabras} palabras")

def contarCaracteres(frase):
    numCaracteres = len(frase)
    print(f"La frase contiene {numCaracteres} caracteres")

def contarVocales(frase):
    numVocales = 0
    for x in frase:
        result = re.search("[aeiouAEIOU]", x)
        if (result != None):
            numVocales+=1
    print(f"La frase contiene {numVocales} vocales")

def contarPuntosyComas(frase):
    numPuntosComas = 0
    for x in frase:
        result = re.search("[,.]", x)
        if (result != None):
            numPuntosComas += 1
    print(f"La frase contiene {numPuntosComas} puntos y comas")

def contarLetrasMayusculas(frase):
    listaCoincidencias = re.findall("(^[A-Z])|(\\. [A-Z])", frase)
    numLetrasMayusc = len(listaCoincidencias)
    print(f"La frase contiene {numLetrasMayusc} letras mayúsculas al comienzo de frases")

def contarVerbos(frase):
    verbos = ["creo", "es","debe","pretender","ser","llega"]

    listaVerbos =[]
    for x in verbos:
        listaVerbos.append(re.findall(x, frase)) 

    numVerbos = len(listaVerbos)
    print(f"La frase contiene {numVerbos} verbos")

def contarPlurales(frase):
    listaPlurales = re.findall("[a-zA-Z]*s ", frase)
    numPlurales = len(listaPlurales)
    print(f"La frase contiene {numPlurales} palabras acabadas en s")

def convertirMayusculas(frase):
    print(frase.upper())

def eliminarEspacios(frase):
    print(frase.replace("  ", " "))

contarPalabras(frase)
contarCaracteres(frase)
contarLetrasMayusculas(frase)
contarVocales(frase)
contarPlurales(frase)
contarPuntosyComas(frase)
contarVerbos(frase)
convertirMayusculas(frase)
eliminarEspacios(frase)