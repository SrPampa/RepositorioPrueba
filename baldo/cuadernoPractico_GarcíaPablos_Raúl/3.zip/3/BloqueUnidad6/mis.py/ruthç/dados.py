import random

def lanzarDados():
    dado = random.randint(1, 6)
    return dado

listaTotalRepeticiones = []
lista = {'2':0, '3':0, '4':0, '5':0, '6':0, '7':0, '8':0, '9':0, '10':0, '11':0, "12":0}
sumaDado1 = 0
sumaDado2 = 0

for i in range(1000):
    print(f"Tirada {i}:", end="")
    dado1 = lanzarDados()
    print(f"{dado1}, ", end="")
    sumaDado1 += dado1
    dado2 = lanzarDados()
    print(dado2)
    sumaDado2 += dado2
    sumaTotal = dado1+dado2
    listaTotalRepeticiones.append(sumaTotal)
    if (sumaTotal==2):
        lista['2']+=1
    elif(sumaTotal==3):
        lista['3']+=1
    elif(sumaTotal==4):
        lista['4']+=1
    elif(sumaTotal==5):
        lista['5']+=1
    elif(sumaTotal==6):
        lista['6']+=1
    elif(sumaTotal==7):
        lista['7']+=1
    elif(sumaTotal==8):
        lista['8']+=1
    elif(sumaTotal==9):
        lista['9']+=1
    elif(sumaTotal==10):
        lista['10']+=1
    elif(sumaTotal==11):
        lista['11']+=1
    elif(sumaTotal==12):
        lista['12']+=1
    
print(lista)
print(f"Suma dado 1: {sumaDado1}")
print(f"Suma dado 2: {sumaDado2}")
diferencia = sumaDado1-sumaDado2
print(f"Diferencia entre los acumulados: {abs(diferencia)}")