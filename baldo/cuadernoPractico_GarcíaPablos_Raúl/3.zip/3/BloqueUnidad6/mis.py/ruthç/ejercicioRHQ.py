import io
import os


def introducirMeta():
    opcion = ""
    while (opcion != "S" and opcion != "s" and opcion != "N" and opcion != "n"):
        opcion = input("¿Deseas introducir meta? S|N ")

    meta = []
    if (opcion == "S" or "s"):
        nombreAutor = input("Introduce el nombre del autor ")
        meta = [["<meta charset=", "\"UTF-8\"", ">"], ["<meta name=\"description\" content=", "SGE, DAM2", ">"],
                ["<meta name=\"keywords\" content=", "Python SGE", ">"],
                ["<meta name=\"author\" content=\"", nombreAutor+"\">"],
                ["<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" >"]]

    return meta


def introducirTitulo():
    opcion = ""
    while (opcion != "S" and opcion != "s" and opcion != "N" and opcion != "n"):
        opcion = input("¿Deseas introducir un título? S|N ")

    if (opcion == "S" or "s"):
        titulo = input("Introduce el título ")

    title = ["<title>", titulo,"</title>"]
    return title


def introducirTransmisionDatos():
    opcion = ""
    while (opcion != "get" and opcion != "post"):
        opcion = input(
            "Introduce el tipo de transmisión de datos al servidor get|post ")

    form = ["<form action= \"recoge.py\" method=\"", opcion, "\">"]
    return form


def introducirFormulario():
    form = introducirTransmisionDatos()
    numElementos = 0
    while (numElementos < 2 or numElementos > 5):
        numElementos = int(
            input("Introduce el número de campos del formulario "))
    for i in range(numElementos):
        tipo = input("Introduce un tipo de campo: button | checkbox | color | date | datetime-local | email | file | hidden | image | month | number | password | radio | range | reset | search | submit | tel | text | time | url | week")
        name = input("Introduce el nombre del campo ")
        form.append(["<input type=\"", tipo, "\"name=\"", name, "\">"])

    form.append("</form>")
    return form


def escribirArchivo(lista, file):
    for elemento in lista:
        if isinstance(elemento, list):
            escribirArchivo(elemento, file)
        else:
            file.write(elemento)


texto = "Contenido del parrafo"
p = ["<p>", texto, "</p>"]
body = ["<body>", p, "</body>"]
head = ["<head>", "</head>"]
html = ["<html>", head, body, "</html>"]
documento = ["<!DOCTYPE html>", html]

meta = introducirMeta()
if (meta != None):
    head.insert(1, meta)

print(meta)

titulo = introducirTitulo()
if (titulo != None):
    head.insert(2, titulo)

print(titulo)
print("head", head)
form = introducirFormulario()

print(form)
if (titulo != None):
    body.insert(2, form)
print(body)

file = open("ejercicioRHQ2.html", "w")
escribirArchivo(documento, file)
file.close()