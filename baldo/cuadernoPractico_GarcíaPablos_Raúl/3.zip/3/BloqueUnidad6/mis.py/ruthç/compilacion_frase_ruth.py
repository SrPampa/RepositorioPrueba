import compileall

compileall.compile_file("frase_ruth.py")