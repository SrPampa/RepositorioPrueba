import webbrowser
from io import open

etiquetas = ["<!DOCTYPE html>", '<html lang="es">', "<head>", ' <meta charset="utf-8">', " <title>HTML 5</title>",
              ' <meta name="viewport">', "</head>", "<body>", "</body>", "</html>"]

def crearHTML(etiquetas):
    ruta="ejercicioRGP.html"
    with open(ruta, mode="w", encoding="utf8") as fichero:
        for i in etiquetas:
            print(i,file= fichero)
        webbrowser.open(ruta)
        
crearHTML(etiquetas)