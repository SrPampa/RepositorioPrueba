
def decoradorCrear(arg,arg2):
	def wrapper(funcion):
		def nuevaFuncion():
			print(arg)
			resutl=funcion()
			print(arg2)
			return resutl
		return nuevaFuncion
	return wrapper

@decoradorCrear("Estoy al principio de la funcion", "Estoy al final de la funcion")
def crearDiccionario():
    
	curso={"Mates":{},"Lengua":{}}
	nombres = ["Juan", "María", "Elena"]
	apellidos = ["Hernández", "Gutiérrez", "Jiménez"]
	edades = ["18","20","19"]
	numerosTelf= ["634736235", "774736235", "600736205"]

	for i in range(3):

		alumno = {"nombre":nombres[i],"apellidos":apellidos[i],"edad":edades[i],"movil":numerosTelf[i]}
		curso["Mates"]["Alumno"+str(i)]=alumno
		curso["Lengua"]["Alumno"+str(i)]=alumno
		print("Alumno "+str(i)+" introducido")
  
	return curso


#curso = crearDiccionario()

def decoradorVisualizar(arg):
    def wrapper(funcion):
        def nuevaFuncion():
            c= arg()
            resutl=funcion(c)
            return resutl
        return nuevaFuncion
    return wrapper
	

				
@decoradorVisualizar(crearDiccionario)
def visualizarDiccionario(curso):
	for i in curso:
		print(i)
		for j in curso[i]:
			print("\t"+j)
			for k, l in curso[i][j].items():
				if (k=="nombre"):
					print("\t\tEl nombre es: "+l)
				if (k=="apellidos"):
					print("\t\tEl apellido es: "+l)
				if (k=="edad"):
					print("\t\tSu edad es: "+l)
				if (k=="movil"):
					print("\t\tSu número de contacto es: "+l)


visualizarDiccionario()
