import re

frase = "Yo creo que la gente, cuando es inteligente y completamente normal, no debe pretender el ser rara o extraña, porque llega al absurdo inventado."
verbos = ["creo", "es", "debe", "pretender", "llega"] #no incluyo "ser" porque está recategorizado y aquí es un sustantivo
'''
En un principio cree este método pero he optado por dejar uno más general y sumar los resultados

def contarVocales():
    numVocales=0
    for i in frase:
        if(i == 'a'):
            numVocales+=1
        if(i == 'e'):
            numVocales+=1
        if(i == 'i'):
            numVocales+=1
        if(i == 'o'):
            numVocales+=1
        if(i == 'u'):
            numVocales+=1    
    return numVocales
'''

def contarChar(caracterBuscado):
    numChar=0
    for i in frase:
        if(i == caracterBuscado):
            numChar+=1
    return numChar


numPalabras = len(frase.split())
print("a) En la frase hay", numPalabras, "palabras")
numCaracteres = len(frase)
print("b) En la frase hay", numCaracteres, "caracteres")
numVocales=contarChar('a')+contarChar('e')+contarChar('i')+contarChar('o')+contarChar('u')
print("c) En la frase hay", numVocales, "vocales")
numComasPuntos = contarChar(',') + contarChar('.')
print("d) En la frase hay", numComasPuntos, "comas y puntos")
listaCoincidencias= re.findall("^[A-Z]| [A-Z]", frase)
numMay= len(listaCoincidencias)
print("e) En la frase hay", numMay, "mayúsculas que comienzan frases")

listaPalabras = frase.split()
numVerbos = 0
for i in listaPalabras:
    for verbo in verbos:
        if (i == verbo):
            numVerbos+=1

print("f) En la frase hay", numVerbos, "verbos")
posiblesPlurales= []
numEns = 0
for i in listaPalabras:
    if(i.endswith("s")|i.endswith("s,")|i.endswith("s.")):
        numEns+=1
        posiblesPlurales.append(i)

print("g) En la frase hay", numEns, "palabras que terminan en -s", posiblesPlurales)

