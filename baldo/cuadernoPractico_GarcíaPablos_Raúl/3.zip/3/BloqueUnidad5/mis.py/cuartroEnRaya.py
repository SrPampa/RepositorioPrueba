import os
import time 

def borrarPantalla():
    if os.name == "posix":
        var = "clear"       
    elif os.name == "ce" or os.name == "nt" or os.name == "dos":
        var = "cls"
    os.system(var) 

'''
def crearTablero(filas, columnas):
    tablero=[]
    for i in range(columnas):
        colum = [str(i+1)]
        for i in range(filas):
            column.append(".")
        tablero.append(column)
'''

def iniciarTablero():
    
    columna0= ["0",".",".",".",".",".","."]
    columna1= ["1",".",".",".",".",".","."]
    columna2= ["2",".",".",".",".",".","."]
    columna3= ["3",".",".",".",".",".","."]
    columna4= ["4",".",".",".",".",".","."]
    columna5= ["5",".",".",".",".",".","."]
    columna6= ["6",".",".",".",".",".","."]
    columna7= ["7",".",".",".",".",".","."]
    tablero = [columna0,columna1,columna2,columna3,columna4,columna5,columna6,columna7]
    return tablero

def mostrarTablero(tablero):
    for i in range(7):
        for colum in tablero:
            print(colum[i], end=" ")
        print()
            
def introducirFicha(tablero, columna, jugador):
    i=6
    while i !=0:
        x= tablero[columna]
        if (x[i]=="."):
            x[i]=jugador
            break
        i-=1
    # if (tablero[columna][1]!="."): una idea para comprobar si la columna estaba llena parar, pero para otra version
    #     print("Columna",tablero[columna][0],"llena")
    return tablero       
         
def revisarColumnas(tablero, color):
    fichas=0
    for column in tablero:
        for i in range(7):
            if (column[i]==color):
                fichas +=1
            else:
                fichas=0
            if (fichas==4):
                return True
        fichas=0
    return False

def revisarFilas(tablero, color):
    fichas=0
    for i in range(1,7):
        for fila in tablero:
            if (fila[i]==color):
                fichas +=1 
            else:
                fichas = 0
            if (fichas==4):
                return True
        fichas=0
    return False

def revisarDiagonales(tablero, color):
    for i in range(4):
        for j in range(4):
            if (tablero[i][j]==color):
                if (tablero[i+1][j+1]==color):
                    if (tablero[i+2][j+2]==color):
                        if (tablero[i+3][j+3]==color):
                            return True   
    for i in range(5):
        for j in range (7):
            if(tablero[i][j]==color):
                if(tablero[i+1][j-1]==color):
                    if(tablero[i+2][j-2]==color):
                        if(tablero[i+3][j-3]==color):
                            return True
    # if (tablero[4][4]==color):
    #     if(tablero[5][3]==color):
    #         if(tablero[6][2]==color):
    #             if(tablero[7][1]==color):
    #                 return True
    return False
def revisarEmpate(tablero):
    colLlenas=0
    for columna in tablero:
        if columna[1]!= ".":
            colLlenas+=1
    if (colLlenas==8):
        return True
    return False
            

            
tablero = iniciarTablero()
mostrarTablero(tablero)

turno = 0

while (True):
    
    if(turno%2==0):
        jugador = "X"
    else:
        jugador = "O"
    print("Turno de-->",jugador)    
    try:
        numero=int(input("Escoge la columna (0-7): "))
        if (numero >=0):
            if (numero <=7):
                columna = numero
                borrarPantalla()
                introducirFicha(tablero, columna, jugador)
                mostrarTablero(tablero)
                if(revisarEmpate(tablero)):
                    print("Empate")
                    break
                if(revisarFilas(tablero, jugador)|revisarColumnas(tablero, jugador)|revisarDiagonales(tablero, jugador)): 
                    print("Ganaste", jugador)
                    break
                turno+=1
            else:
                if (numero == 99): #esto es una salida de emergencia introduciendo 99
                    break
                print("Debes introducir un número entre 0 y 7")
        else:
            
            print("Debes introducir un número entre 0 y 7")
    except ValueError:
        print("Te has equivocado al introducir un numero")
