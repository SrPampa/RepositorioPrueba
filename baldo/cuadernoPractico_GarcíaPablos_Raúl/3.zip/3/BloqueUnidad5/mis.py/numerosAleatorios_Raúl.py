from random import choice, randint, random, uniform

p1=(randint(0,30))
p2=(uniform(0,10))
p3=(random())
p4=(choice(["A","B","C"]))

print("Paso1:",p1) #Con una coma puedo concatenar variables y se añade un espacio
print("Paso2: "+str(p2)) #Si uso la concatrenacion tengo que castear la variable numérica
print("Paso3:"+str(p3)) #De esta forma hay que recordar que no se añaden espacio
print("Paso4:",p4)

'''
Aparte de con # pordemos dejar bloques de comentarios con 3 apóstrofes
Vamos ahora a resolver los otros dos pasos de la practica
'''

listaPalabras = ["tierra","equipo","segundo","director","dicho","cierto","casos",
   "manos","nivel","familia","falta","llegar","propio", "ministro","cosa","primero", 
   "seguridad","hemos","mal","trata","algún","respecto","semana","varios","real","voz",
   "paso","señor","proyecto","mercado"]
seleccion =[]

while len(seleccion)<10: #añadiré palabras a la selección hasta que tenga 10
    repetido=False #añado un boolean al bucle para hacer una comprobación
    palabraAzar= choice(listaPalabras)    
    for x in seleccion: #recorro lo que tenemos de lista para comprobar que no tengo palabras repetidas
        if (x == palabraAzar):
            repetido=True
    if (repetido==False): #Si no hay ninguna palabra repetida añado una a la selección
        seleccion.append(palabraAzar)                 
    
print("*****Paso 5:","\nDe esta lista:",listaPalabras,"\nObtenemos estas 10 palabras:", seleccion)

listaNums = []

while len(listaNums)<5: 
    repetido=False 
    numAleatorio= randint(1,50)    
    for x in listaNums: 
        if (x == numAleatorio):
            repetido=True
    if (repetido==False): 
        listaNums.append(numAleatorio)    
        
print("*****Paso 6:","\n5 números (distintos) del 1 al 50:", listaNums)                  