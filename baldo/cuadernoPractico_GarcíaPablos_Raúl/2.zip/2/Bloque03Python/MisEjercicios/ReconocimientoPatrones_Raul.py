copulativas = ["y [e]","ni"]
disyuntivas = ["o [u]", "o bien"]
distributivas = ["bien", "ya... ya", "ora... ora"]
consecutivas = ["luego", "conque", "así que", "así pues", "pues bien"]
adversativas = ["pero", "sino", "mas", "aunque", "a pesar de que"]
explicativas = ["o sea", "es decir", "esto es", "por ejemplo"]
completivas = ["que", "si"]
causales = ["que", "porque", "como", "pues", "dado que", "puesto que"]
concesivas = ["aunque", "por más que", "por mucho que", "si bien"]
condicionales = ["si", "como", "cuando", "con tal que", "con que"]
finales = ["que", "para que", "a fin de que"]
temporales = ["cuando", "mientras (que)", "en cuanto", "una vez que"]
modales = ["como", "según"]
consecutivas = ["tan", "tal", "tanto... que"]
comparativas = ["más", "menos", "mejor", "peor... que", "tan... como"]


clasesCoor = {"Copulativas":copulativas, "Disyuntivas":disyuntivas, "Distributivas":distributivas, "Consecutivas":consecutivas, 
"Adversativas":adversativas,"Explicativas":explicativas}
clasesSub = {"Completivas":completivas, "Causales":causales, "Concesivas":concesivas, "Condicionales":condicionales, 
"Finales":finales, "Temporales":temporales, "Modales":modales, "Consecutivas":consecutivas, "Comparativas":comparativas}


conjunciones= {
	"Coordinantes":clasesCoor,
	"Subordinantes":clasesSub
}

print("\n------------------------------------------")
print(conjunciones)
print("------------------------------------------\n")

for i in conjunciones:
	print(i)
	for j in conjunciones[i]: 
		print("\t"+j)
		for k in conjunciones[i][j]:
			print("\t\t"+k)
