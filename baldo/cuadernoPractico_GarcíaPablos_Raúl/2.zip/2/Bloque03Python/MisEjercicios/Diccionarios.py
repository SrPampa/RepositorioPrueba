print("Vamos a crear un diccionario, introduzca los valores indicados (se van a pedir 3 registros)")

curso={"sge":{},"programacion":{}}

for i in range(3):
	nombre = input("Introduzca el nombre: ")
	apellido = input("Introduzca los apellidos: ")
	edad = input("Introduzca la edad: ")
	movil = input("Introduzca numero de contacto: ")
	alumno = {"nombre":nombre,"apellidos":apellido,"edad":edad,"movil":movil}
	curso["sge"]["alumno"+str(i+1)]=alumno
	curso["programacion"]["alumno"+str(i+1)]=alumno
	print("alumno "+str(i+1)+" introducido")
	
for clave in curso:
	print(clave)
	for i in curso[clave]:
		print("\t"+i)
		for x, y in curso[clave][i].items():
			print("\t\t"+x+": "+y)

print(curso)

'''
for i in curso:
	for j in curso[i]:
		for k in curso[i][j]:

curso={"materia":
		{"alumno":
			{"nombre":"",
			"apellido":"",
			"edad":},
		},
	"lengua":""}
'''