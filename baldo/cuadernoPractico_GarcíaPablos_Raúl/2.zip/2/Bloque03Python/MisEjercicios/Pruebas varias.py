print("hello de nuevo")
vuelta = 0
while True:
	print("introduce q para salir")
	seguir = input()
	if (seguir == 'q'):
		break
	else:
		print("vuelta "+ str(vuelta))
		vuelta+=1

