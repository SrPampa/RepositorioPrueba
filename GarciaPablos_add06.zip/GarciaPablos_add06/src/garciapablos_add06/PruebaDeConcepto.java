/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garciapablos_add06;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author 6002291
 */
public class PruebaDeConcepto {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String url;
        do {
            System.out.println("Introduzca una url válida: ");
            url = sc.nextLine();
            /* direcciones válidas para el ejercicio:   
            https://qrng.anu.edu.au/API/jsonI.php?length=10&type=uint8
            http://ip.jsontest.com/
            http://date.jsontest.com
            http://md5.jsontest.com/?text=dato
            https://jsonplaceholder.typicode.com/todos/123
             */

        } while (!url.startsWith("http://") && !url.startsWith("https://"));

        crearComprobarBD();

        //creo el objeto de la clase URL para poder sacar la info de la internet
        URL urlObj;
        try {
            urlObj = new URL(url);
            BufferedReader urlReader;
            urlReader = new BufferedReader(new InputStreamReader(urlObj.openStream()));
            String inputLine;
            System.out.println("Info recibida de la url: "+url+":");
            while ((inputLine = urlReader.readLine()) != null) {
                System.out.println(inputLine);
            }
            urlReader.close();
        } catch (MalformedURLException ex) {
            System.err.println("*********problema con la url introducida*******");
            ex.getStackTrace();
        } catch (IOException ex) {
            ex.getStackTrace();
        }

    }

    private static void crearComprobarBD() {

        String rutaBaseDatos = "./GarciaPablos_add06.datos";
        File f = new File(rutaBaseDatos);

        if (f.exists()) {
            System.out.println("Archivo GarciaPablos_add06.datos sqlite existente, continúa el programa...");
        } else {
            System.out.println("Creando base de datos... ");
            String cadenaConexion = "jdbc:sqlite:" + rutaBaseDatos;
            Connection conn;
            try {
                conn = DriverManager.getConnection(cadenaConexion);
                conn.close();
                //CREAR TABLA   
                creatabla(cadenaConexion);

            } catch (SQLException ex) {
                System.err.println("Excepción sql");
                ex.printStackTrace();
            }
            System.out.println("Base de datos sqlite: GarciaPablos_add06.datos creada con éxito");

        }

    }

    private static void creatabla(String cadenaConexion) throws SQLException {

        Connection objCnxn = DriverManager.getConnection(cadenaConexion);
        Statement objSttmnt = objCnxn.createStatement();

        String sqlCreaTabla = "CREATE TABLE IF NOT EXISTS TablaDatos ("
                + "fecha TEXT NOT NULL,"
                + "hora TEXT NOT NULL,"
                + "ip1 INTEGER NOT NULL,"
                + "ip2 INTEGER NOT NULL,"
                + "ip3 INTEGER NOT NULL,"
                + "ip4 INTEGER NOT NULL,"
                + "frase TEXT NOT NULL,"
                + "hash_frase TEXT NOT NULL,"
                + "PRIMARY KEY (fecha, hora, ip1, ip2, ip3, ip4));"; //establezco una clase primaria conjunta para asegurarme de que no puede haber filas duplicadas con los mismos valores en esas columnas.

        objSttmnt.execute(sqlCreaTabla);

        objSttmnt.close();
        objCnxn.close();
    }

}
