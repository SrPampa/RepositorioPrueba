/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garciapablos_add06;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * programa que recoge datos de unas url que devuelven json, se tratan esos json
 * para recoger la información que queremos y la introducen en un archivo de
 * base de datos sqlite
 *
 * SI SE QUIERE EJECUTAR POR PRIMERA VEZ SIN QUE EXISTA LA BASE DE DATOS DEBE
 * BORRARSE PREVIAMENTE DEL PROPIO PROYECTO GarciaPablos_add06.datos
 *
 * @author 6002291
 */
public class GarciaPablos_add06 {

    public static void main(String[] args) throws JSONException {

        Random random = new Random();
        int numAleatorio = random.nextInt(200) + 1; //creo un numero aleatorio para recoger en cada ejecución un texto en latín distinto
        String[] urls = {
            "http://ip.jsontest.com/",
            "http://date.jsontest.com",
            "https://jsonplaceholder.typicode.com/todos/" + numAleatorio,
            "http://md5.jsontest.com/?text=" //a esta url que es la url[3] le sumaré el texto en latín que recojamos (los espacios serán %20 para que funcione correctametne
        };
//CREAR BD
        crearComprobarBD();

        //creo el objeto de la clase URL para poder sacar la info de la internet
        URL urlObj;
        //declaro e inicializo los datos que voy a extraer de las urls
        String fecha = "";
        String hora = "";
        int ip1 = 0;
        int ip2 = 0;
        int ip3 = 0;
        int ip4 = 0;
        String frase = "";
        String hash_frase = "";
//RECOGER
        for (int i = 0; i < 4; i++) { //creo un for para que entre en cada una de las urls que tengo en mi array de strings
            if (i == 3) { //este if es para que no falle la url del md5 por los espacios de la frase
                String frase_url = frase.replace(" ", "%20");
                urls[3] = urls[3] + frase_url;
            }

            StringBuilder sb = new StringBuilder();
            try {
                urlObj = new URL(urls[i]);
                BufferedReader urlReader;
                urlReader = new BufferedReader(new InputStreamReader(urlObj.openStream()));
                String inputLine;
                //      System.out.println("Info recibida de la url: " + urls[i] + ":");
                while ((inputLine = urlReader.readLine()) != null) {
                    //          System.out.println(inputLine);
                    sb.append(inputLine);
                }
                urlReader.close();
            } catch (MalformedURLException ex) {
                System.err.println("Problema con la url introducida");
                ex.getStackTrace();
            } catch (IOException ex) {
                ex.getStackTrace();
            }
            String cadenaJSON = sb.toString();
            //   System.out.println("String builder: " + cadenaJSON);
//TRATAR
            //EN CADA URL VOY A TENER QUE TRATAR EL JSON DE UNA MANERA Y EXTRAER LOS DATOS QUE ME INTERESEN
            switch (i) {
                case 0:
                    int[] octetos = extraerIPs(cadenaJSON);
                    ip1 = octetos[0];
                    ip2 = octetos[1];
                    ip3 = octetos[2];
                    ip4 = octetos[3];
                    break;
                case 1:
                    fecha = extraerFecha(cadenaJSON);
                    hora = extraerHora(cadenaJSON);
                    break;
                case 2:
                    frase = extraerFrase(cadenaJSON);
                    break;
                case 3:
                    hash_frase = extraerHash(cadenaJSON);
                    break;
                default:
                    throw new AssertionError();
            }

        } //fin del for
//MOSTRAR INTRODUCIDO
        System.out.println("""
                           Fila que se va a introducir en la TablaDatos
                           |\thash_frase: """ + hash_frase + "\t|\tfecha: " + fecha
                + "\t|\thora: " + hora + "\t|\tip1: " + ip1 + "\t|\tip2: " + ip2 + "\t|\tip3: "
                + ip3 + "\t|\tip4: " + ip4 + "\t|\tfrase: " + frase);

//ALMACENAR
        try {
            String rutaBaseDatos = "./GarciaPablos_add06.datos";
            String cadenaConexion = "jdbc:sqlite:" + rutaBaseDatos;
            Connection conn = DriverManager.getConnection(cadenaConexion);
            String sql = "INSERT INTO TablaDatos VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, fecha);
            pstmt.setString(2, hora);
            pstmt.setInt(3, ip1);
            pstmt.setInt(4, ip2);
            pstmt.setInt(5, ip3);
            pstmt.setInt(6, ip4);
            pstmt.setString(7, frase);
            pstmt.setString(8, hash_frase);
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();

        } catch (SQLException ex) {
            System.err.println("Error al introducir datos en la tabla");
            ex.getStackTrace();
        }

//MOSTAR TODOS LOS DATOS QUE CONTIENE LA TABLA 
        try {

            String rutaBaseDatos = "./GarciaPablos_add06.datos";
            String cadenaConexion = "jdbc:sqlite:" + rutaBaseDatos;
            Connection conn = DriverManager.getConnection(cadenaConexion);

            Statement query = conn.createStatement();

            String sql_query = "SELECT * FROM TablaDatos";

            ResultSet lista = query.executeQuery(sql_query);
            System.out.println("Todos los datos extraidos de TablaDatos: ");
            while (lista.next()) {
                System.out.println("|\thash_frase: " + lista.getString(8) + "\t|\tfecha: " + lista.getString(1)
                        + "\t|\thora: " + lista.getString(2) + "\t|\tip1: " + lista.getInt(3) + "\t|\tip2: " + lista.getInt(4) + "\t|\tip3: "
                        + lista.getInt(5) + "\t|\tip4: " + lista.getInt(6) + "\t|\tfrase: " + lista.getString(7));
            }
            lista.close();//cerrar ResultSet
            query.close();//cerrar Statement
            conn.close();//cerrar Connection
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }

    }

    private static void crearComprobarBD() {

        String rutaBaseDatos = "./GarciaPablos_add06.datos";
        File f = new File(rutaBaseDatos);

        if (f.exists()) {
            System.out.println("Archivo GarciaPablos_add06.datos sqlite existente, continúa el programa...");
        } else {
            System.out.println("Creando base de datos... ");
            String cadenaConexion = "jdbc:sqlite:" + rutaBaseDatos;
            Connection conn;
            try {
                conn = DriverManager.getConnection(cadenaConexion);
                conn.close();
                //CREAR TABLA   
                creatabla(cadenaConexion);

            } catch (SQLException ex) {
                System.err.println("Excepción sql");
                ex.printStackTrace();
            }
            System.out.println("Base de datos sqlite: GarciaPablos_add06.datos creada con éxito");

        }

    }

    private static void creatabla(String cadenaConexion) throws SQLException {

        Connection objCnxn = DriverManager.getConnection(cadenaConexion);
        Statement objSttmnt = objCnxn.createStatement();

        String sqlCreaTabla = "CREATE TABLE IF NOT EXISTS TablaDatos ("
                + "fecha TEXT NOT NULL,"
                + "hora TEXT NOT NULL,"
                + "ip1 INTEGER NOT NULL,"
                + "ip2 INTEGER NOT NULL,"
                + "ip3 INTEGER NOT NULL,"
                + "ip4 INTEGER NOT NULL,"
                + "frase TEXT NOT NULL,"
                + "hash_frase TEXT NOT NULL,"
                + "PRIMARY KEY (fecha, hora, ip1, ip2, ip3, ip4));"; //establezco una clase primaria conjunta para asegurarme de que no puede haber filas duplicadas con los mismos valores en esas columnas.

        objSttmnt.execute(sqlCreaTabla);

        objSttmnt.close();
        objCnxn.close();
    }

    private static int[] extraerIPs(String cadenaJSON) throws JSONException {

        JSONObject jsonObj = new JSONObject(cadenaJSON);
        String ip_completa = jsonObj.get("ip").toString();

        String[] aux = ip_completa.split("\\.");

        int[] octetos = new int[aux.length];

        for (int i = 0; i < aux.length; i++) {
            octetos[i] = Integer.parseInt(aux[i]);
        }

        return octetos;
    }

    private static String extraerFecha(String cadenaJSON) throws JSONException {
        JSONObject jsonObj = new JSONObject(cadenaJSON);
        return jsonObj.get("date").toString();
    }

    private static String extraerHora(String cadenaJSON) throws JSONException {
        JSONObject jsonObj = new JSONObject(cadenaJSON);
        return jsonObj.get("time").toString();
    }

    private static String extraerFrase(String cadenaJSON) throws JSONException {
        JSONObject jsonObj = new JSONObject(cadenaJSON);
        return jsonObj.get("title").toString();
    }

    private static String extraerHash(String cadenaJSON) throws JSONException {
        JSONObject jsonObj = new JSONObject(cadenaJSON);
        return jsonObj.get("md5").toString();
    }

}
