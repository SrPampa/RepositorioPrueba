# -*- coding: utf-8 -*-
from odoo import http


class Tallerroma(http.Controller):
    @http.route('/tallerroma/tallerroma', auth='public')
    def index(self, **kw):
        return "Hello, world"

    @http.route('/tallerroma/tallerroma/objects', auth='public')
    def list(self, **kw):
        return http.request.render('tallerroma.listing', {
            'root': '/tallerroma/tallerroma',
            'objects': http.request.env['tallerroma.tallerroma'].search([]),
        })

    @http.route('/tallerroma/tallerroma/objects/<model("tallerroma.tallerroma"):obj>', auth='public')
    def object(self, obj, **kw):
        return http.request.render('tallerroma.object', {
            'object': obj
        })
