# -*- coding: utf-8 -*-
{
    'name': "tallerroma",

    'summary': """
       Taller multimarca especializado en mecánica, chapa y pintura""",

    'description': """
        proyecto para superar la asignatura de SGE y futuras actuailizaciones para su uso profesional en el taller roma 2.0 real
    """,

    'author': "Raúl García Pablos",
    'website': "https://tallerroma20.negocio.site/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Tools - Taller',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale_management', 'account'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        #'views/templates.xml',
    ],
    'action': {
        'name': 'Vehículos',
        'type': 'ir.actions.act_window',
        'res_model': 'tallerroma.vehiculo',
        'view_mode': 'tree,form',
        'help': 'Muestra todos los vehículos',
    },

    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
