# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import datetime


class Vehiculo(models.Model):
    _name = 'tallerroma.vehiculo'
    _description = 'Modelo para representar los vehículos de los clientes'

    matricula = fields.Char('Matrícula', required=True)
    fecha_vehiculo = fields.Date('Fecha antigüedad')
    modelo = fields.Text(string='Modelo')
    marca = fields.Text(string='Marca')
    kilometros = fields.Integer('Kilómetros', default=0)
    imagen = fields.Binary(string='Imagen')

    cliente_id = fields.Many2one('tallerroma.clientes', string='Cliente')

    fecha_creacion = fields.Datetime('Fecha de creación', default=lambda self: fields.datetime.now(), readonly=True)
    fecha_modificacion = fields.Datetime('Fecha de última modificación', default=lambda self: fields.datetime.now(),
                                         readonly=True)

    @api.constrains('kilometros')
    def _check_kilometros(self):
        if self.kilometros < 0:
            raise ValidationError("Los kilómetros no pueden ser negativos.")

    def antiguedad(self):
        if self.fecha_vehiculo:
            fecha_actual = datetime.now().date()
            fecha_vehiculo = fields.Date.from_string(self.fecha_vehiculo)
            antiguedad = fecha_actual.year - fecha_vehiculo.year - (
                    (fecha_actual.month, fecha_actual.day) < (fecha_vehiculo.month, fecha_vehiculo.day))
            return antiguedad
        else:
            return False

    #incluyo name_get para que aparezca la matricula en vez del nombre por defecto tallerroma.vehiculo,1
    @api.depends('matricula')
    def name_get(self):
        result = []
        for record in self:
            name = record.matricula
            result.append((record.id, name))
        return result


class Clientes(models.Model):
    _name = 'tallerroma.clientes'
    _description = 'modelo para representar el cliente de cada coche'

    dni = fields.Char('DNI', required=True, index=True)
    email = fields.Char('Email')
    telefono = fields.Char('Número de teléfono')
    direccion = fields.Char('Dirección')
    nombre = fields.Char('Nombre', required=True)
    apellidos = fields.Char('Apellidos', required=True)

    vehiculos_relacionados = fields.One2many('tallerroma.vehiculo', 'cliente_id', string='Vehículos')

    fecha_creacion = fields.Datetime('Fecha de creación', default=lambda self: fields.datetime.now(), readonly=True)
    fecha_modificacion = fields.Datetime('Fecha de última modificación', default=lambda self: fields.datetime.now(),
                                         readonly=True)

    @api.constrains('dni')
    def _check_dni(self):
        if not self.dni.isdigit() or len(self.dni) != 8:
            raise ValidationError("El DNI debe contener 8 números (la letra no hace falta)")

    @api.constrains('email')
    def _check_email(self):
        if self.email and '@' not in self.email:
            raise ValidationError("El email debe ser una dirección válida.")

    @api.constrains('telefono')
    def _check_telefono(self):
        if self.telefono and not self.telefono.isdigit():
            raise ValidationError("El número de teléfono debe contener sólo números.")

    @api.constrains('nombre')
    def _check_nombre(self):
        if self.nombre and not self.nombre.isalpha():
            raise ValidationError("El nombre sólo pueden contener letras.")

        # Campo relacionado para mostrar la cantidad de vehículos del cliente en cuestión

    cantidad_vehiculos = fields.Integer(string='Cantidad de vehículos ', compute='_compute_cantidad_vehiculos',
                                        store=True)

    @api.depends('vehiculos_relacionados')
    def _compute_cantidad_vehiculos(self):
        for record in self:
            record.cantidad_vehiculos = len(record.vehiculos_relacionados)

    # Agrego el atributo display_name con el valor "dni" para que el DNI del cliente se muestre en la vista.
    @api.depends('dni')
    def _compute_display_name(self):
        for record in self:
            record.display_name = record.dni

    display_name = fields.Char(string="Nombre", compute="_compute_display_name", store=True)
