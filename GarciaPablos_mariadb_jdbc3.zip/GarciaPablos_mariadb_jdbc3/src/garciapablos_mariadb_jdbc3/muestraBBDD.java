/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_mariadb_jdbc3;

import java.sql.*;

/**
 *
 * @author 6002291
 */
public class muestraBBDD {

    static final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
    static final String DB_URL = "jdbc:mariadb://localhost:3303/";

    static final String USER = "root";
    static final String PASS = "12qwASZX";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);

            System.out.println("Connecting to MariaDB server...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            System.out.println("****El servidor de mariadb está iniciado****");
            System.out.println("Recogiendo la lista de databases...");
            stmt = conn.createStatement();
            String sql = "SHOW DATABASES";
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Lista de databases: ");
            System.out.println("-------------------");
            while (rs.next()) {
                String dbName = rs.getString("Database");
                System.out.println(dbName);
            }
            System.out.println("-------------------");
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException se) { //SI EL SERVIDOR NO ESTÁ ACTIVO SALTARÁ UNA EXCEPCIÓN SQL, ESTA ES LA VERIFICACIÓN

            System.out.println("*****************El servidor de mariaDB no está iniciado, revise el error e intente arreglarlo*****************\nEste es el seguimiento del error:");

            se.printStackTrace();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
