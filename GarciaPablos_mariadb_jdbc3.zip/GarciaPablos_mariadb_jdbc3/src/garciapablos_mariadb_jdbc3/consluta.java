/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_mariadb_jdbc3;

import java.sql.*;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author 6002291
 */
public class consluta {

    static final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
    static final String DB_URL = "jdbc:mariadb://localhost:3303/GarciaPablosMariaDB";
    static final String USER = "root";
    static final String PASS = "12qwASZX";

    public static void main(String[] args) {

        String tabla;
        String nombre;
        boolean correcto = false;

        Statement stmt = null;
        Connection conn = null;

        try {
            Class.forName(JDBC_DRIVER);

            System.out.println("Conectando a base de datos GarciaPablosMariaDB...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            //pedir al usuario una tabla y un nombre:
            Scanner sc = new Scanner(System.in);
            do {
                System.out.println("Escriba la tabla donde quiera buscar \n(P)Pacientes \n(D)Doctores");
                tabla = sc.nextLine();
                char letra = tabla.toLowerCase().charAt(0);
                if (letra == 'p') {
                    tabla = "pacientes";
                    correcto = true;
                } else if (letra == 'd') {
                    tabla = "doctores";
                    correcto = true;
                } else {
                    System.out.println("Debe escribir una tabla válida");
                    correcto = false;
                }
            } while (!correcto);

            System.out.println("Escriba un nombre que quiera buscar en la tabla " + tabla + ": ");
            nombre = sc.nextLine();

            System.out.println("Creando el statement...");
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT * FROM " + tabla + " WHERE nombre = '" + nombre + "'";
            ResultSet rs = stmt.executeQuery(sql);

            if (tabla.equals("pacientes")) {
                while (rs.next()) { // dni, nombre, apellidos, municipio, cp, calle, numero, piso, letra, telefono, altura, peso, fecha
                    int dni = rs.getInt("dni");
                    String name = rs.getString("nombre");
                    String apellidos = rs.getString("apellidos");
                    String municipio = rs.getString("municipio");
                    int cp = rs.getInt("cp");
                    String calle = rs.getString("calle");
                    int numero = rs.getInt("numero");
                    int piso = rs.getInt("piso");
                    String letra = rs.getString("letra");
                    int telefono = rs.getInt("telefono");
                    int altura = rs.getInt("altura");
                    int peso = rs.getInt("peso");
                    long fecha = rs.getLong("fecha");//como tengo un formato epoch tengo que pasarlo a formato "dd/MM/yyyy"
                    Date date = new Date(fecha*1000);// para el epoch en java hay que añadirle 3 ceros por los segundos
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

                    System.out.print("\n|DNI: " + dni + "\t|Nombre: " + name + "\t|Apellidos: " + apellidos + "\t|Municipio: " + municipio
                            + "\t|CP: " + cp + "\t|Calle: " + calle + "\t|Nº" + numero + "\t|Piso: " + piso + "\t|Letra :" + letra + "\t|Teléfono: " + telefono
                            + "\t|Altura: " + altura + "\t|Peso: " + peso + "\t|Fecha nacimiento: " +formatter.format(date));

                }
                rs.close();
                stmt.close();
                conn.close();
            } else if (tabla.equals("doctores")) {
                while (rs.next()) { // dni, nombre, apellidos, municipio, cp, calle, numero, piso, letra, telefono, fecha, especialidad
                    int dni = rs.getInt("dni");
                    String name = rs.getString("nombre");
                    String apellidos = rs.getString("apellidos");
                    String municipio = rs.getString("municipio");
                    int cp = rs.getInt("cp");
                    String calle = rs.getString("calle");
                    int numero = rs.getInt("numero");
                    int piso = rs.getInt("piso");
                    String letra = rs.getString("letra");
                    int telefono = rs.getInt("telefono");
                    
                    long fecha = rs.getLong("fecha"); //como tengo un formato epoch tengo que pasarlo a formato "dd/MM/yyyy"
                    Date date = new Date(fecha*1000);
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                            
                    String especialidad = rs.getString("especialidad");

                    System.out.print("DNI: " + dni + "\t|Nombre: " + name + "\t|Apellidos: " + apellidos + "  \t|Muicipio: " + municipio
                            + "\t|CP: " + cp + "\t|Calle: " + calle + "\t|Nº" + numero + "\t|Piso: " + piso + "\t|Letra :" + letra + "\t|Teléfono: " + telefono
                            + "\t|Fecha nacimiento: " + formatter.format(date) + "\t|Especialidad: " + especialidad);

                }
                rs.close();
                stmt.close();
                conn.close();
            } else {
                System.err.println("Ha ocurrido algún error");
            }

        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }

}
