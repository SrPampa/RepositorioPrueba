/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_mariadb_jdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;


/**
 *
 * @author 6002291
 */
public class generaBDmariadb {

    static final String USER = "root";
    static final String PASS = "12qwASZX";

    //Declaro arrays para harcodear strings
    private static String[] nombres = {"María", "Ana", "Isabel", "Carmen", "Rosa", "Laura", "Marta", "Teresa", "Dolores", "Silvia", "Raquel", "Pilar", "Lucía", "Aurora", "Araceli", "Patricia", "Alejandra", "Eva", "Martina", "Gema", "Mónica", "Belén", "Esther", "Nuria", "Daniela", "Sara", "Julia", "Encarnación", "Yolanda", "Esther", "Elisa", "Alba", "Claudia", "Amparo", "Esther", "Inés", "Nerea", "Soledad", "Beatriz", "Montse", "Virginia", "Rocío", "Marisol", "Cristina", "Adriana", "Magdalena", "Paqui", "Julia", "Lourdes", "Juan", "José", "Francisco", "Manuel", "Antonio", "David", "Miguel", "Daniel", "Carlos", "Juan Carlos", "Rafael", "Santiago", "Rodrigo", "Jorge", "Alberto", "Javier", "Alberto", "Luis", "Joaquín", "Mario", "Jose Manuel", "Angel", "Ángel", "Sergi", "Josep", "Rubén", "Víctor", "Oscar", "Adrian", "Daniel", "Esteban", "Julio", "Jorge", "Enrique", "Guillermo", "Nicolás", "Ignacio", "Rubén", "Mario", "Diego", "Andrés", "Héctor", "Fermín", "Mario", "Germán", "Hector", "Isaac", "Bruno", "Iker", "Hector", "Xavier", "Leonardo", "Sergio"};
    private static String[] apellidos = {"García", "González", "Rodríguez", "Fernández", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Martin", "Jiménez", "Ruiz", "Hernández", "Diaz", "Moreno", "Muñoz", "Álvarez", "Romero", "Alonso", "Gutiérrez", "Navarro", "Torres", "Domínguez", "Vázquez", "Ramos", "Gil", "Ramírez", "Serrano", "Blanco", "Molina", "Morales", "Suarez", "Ortega", "Delgado", "Castro", "Ortiz", "Rubio", "Marín", "Sanz", "Núñez", "Iglesias", "Medina", "Garrido", "Cortes", "Castillo", "Santos", "Lozano", "Guerrero", "Cano", "Prieto", "Méndez", "Cruz", "Calvo", "Gallego", "Vidal", "León", "Márquez", "Herrera", "Peña", "Flores", "Cabrera", "Campos", "Vega", "Fuentes", "Carrasco", "Diez", "Caballero", "Reyes", "Nieto", "Aguilar", "Pascual", "Santana", "Herrero", "Lorenzo", "Montero", "Hidalgo", "Giménez", "Ibáñez", "Ferrer", "Duran", "Santiago", "Benítez", "Mora", "Vicente", "Vargas", "Arias", "Carmona", "Crespo", "Román", "Pastor", "Soto", "Sáez", "Velasco", "Moya", "Soler", "Parra", "Esteban", "Bravo", "Gallardo", "Rojas"};
    private static String[] municipio = {"Madrid", "Barcelona", "Valencia", "Sevilla", "Zaragoza", "Malaga", "Murcia", "Palma de Mallorca", "Las Palmas de Gran Canaria", "Bilbao", "Alicante", "Córdoba", "Vigo", "Girona", "Lleida", "Granada", "Tarragona", "Badalona", "Santander", "Oviedo", "Málaga", "San Sebastián", "Almería", "La Coruña", "Santa Cruz de Tenerife", "Burgos", "Salamanca", "León", "Pamplona", "Huelva", "Logroño", "Alcalá de Henares", "Cartagena", "Jaén", "Castellón de la Plana", "Cádiz", "Guadalajara", "Getafe", "Fuenlabrada", "Alcorcón", "Torrejón de Ardoz", "Parla", "Majadahonda", "Alcalá de Guadaíra", "Leganés", "Algorta", "San Fernando", "Aranjuez", "Dos Hermanas", "Telde"};
    private static String[] calles = {"Inglaterra", "El Roqueo", "Estrela", "José matía", "Constitución", "Valadouro", "Calle Ancha", "La Fontanilla", "Lamas Carbajal", "Carretera vieja", "Crta. Cádiz", "Camiño Ancho", "Avda. Generalísimo", "Paraguay", "Comandante Izarduy", "Carretera del Muelles", "Ctra. Hornos", "Cartagena", "Calle Carril", "Celso Emilio Ferreira", "Zumalakarregi etorbidea", "Quevedo", "Socampo", "Av. Zumalakarregi", "Paraguay", "Avda. Rio de la plata", "Rosa de los vientos", "Alvaro Cunqueiro", "Cádiz", "Atamaria", "Ventanilla de Bea", "Avda. Alameda", "La Fontanilla", "Comandante Izarduy", "Plaza Maior", "Ctra. Bea-Bermudez", "Avda. Andalucía", "José matías", "Avda. Andalucía sureña", "Ourense", "Reiseñor", "Visitación de la mancha", "Ctra. de los caídos", "Avda. Logroño", "Ventanilla los Locos", "Pza. Fuensanta", "Fuente del Gallieo", "Avenida Cervantes", "Visitación", "La Fontanilla", "Avda. Enrique VIII", "Bellavista", "Boriñaur enparantza", "Paseo Junquera", "C/ Larga", "Salzillo", "Prolongacion Sagrada", "Paraguay", "Cuba", "Cercas Bajas", "Ctra. de la Mancha", "Rosa del giño", "Paseo del Atlántico", "Constitución", "Paseo de Alcobendas", "España", "Pascual Yunquera", "Antonio Vázquez", "Atamaria", "Camiño Real", "Calle Proceduria", "Plazuela do Porto", "Ctra. Bailém", "Enxertos 62", "Avda. Ribera maya", "Rua da Rapin", "Ctra. Hornos altos", "Ctra. Hornos bajos", "Calle Carril de caballos", "Zumalakarregi etorbidea", "Carretera", "Rúa Olmos", "Quevedo", "Urzáiz", "Ctra. Beas-Cortijos", "Outid de Arriba", "Avda. Los Cedros", "José matía", "C/ Fernández de Leceta", "C/ Canarias", "C/ Amoladera", "C/ Los Herrán", "C/ Los Herrán", "C/ Pablo Iglesias", "C/ Rosa de los Vientos", "C/ Domingo Beltrán", "C/ Cañada del Rosal", "C/ Pablo Iglesias", "C/ Cuevas de Ambrosio", "C/ Hijuela de Lojo"};
    private static String[] especialidades = {"Cardiología", "Dermatología", "Ginecología", "Neurología", "Oncología", "Ortopedia", "Pediatría", "Psiquiatría", "Reumatología", "Urología"};

    public static void main(String[] args) {

        //CREAR BASE DE DATOS
        String nombreBaseDatos = "GarciaPablosMariaDB";
        String cadenaConexion = "jdbc:mariadb://localhost:3303/";
        
        try {
            //cargar el driver
            Class.forName("org.mariadb.jdbc.Driver");
            //conexión
            Connection conn = null;
            conn = DriverManager.getConnection(cadenaConexion, USER, PASS);
            String creaBaseDatosSQL = "Create database if not exists " + nombreBaseDatos;
            Statement objSTTMNT = conn.createStatement();
            objSTTMNT.execute(creaBaseDatosSQL);
            conn.close();
            //CREAR TABLAS        
            creatablas(cadenaConexion + nombreBaseDatos);
            //INTRODUCIR DATOS 
            for (int i = 0; i < 100; i++) {
                introducirDatosPacientes(cadenaConexion + nombreBaseDatos);
            }
            for (int i = 0; i < 25; i++) {
                introducirDatosDoctores(cadenaConexion + nombreBaseDatos);
            }

        } catch (SQLException ex) {
            System.err.println("Excepción sql");
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        System.out.println("Base de datos GarciaPablosMariaDB creada con éxito");

    }

    private static void creatablas(String cadenaConexion) throws SQLException {

        Connection objCnxn = DriverManager.getConnection(cadenaConexion, USER, PASS);
        Statement objSttmnt = objCnxn.createStatement();

        String sqlCreaTabla = "CREATE TABLE IF NOT EXISTS Pacientes (DNI integer PRIMARY KEY, "
                + "Nombre text NOT NULL, Apellidos text NOT NULL, Municipio text NOT NULL, CP integer NOT NULL, "
                + "Calle text NOT NULL, Numero integer NOT NULL, Piso integer NOT NULL, "
                + "Letra text NOT NULL, Telefono integer NOT NULL, Altura integer NOT NULL, "
                + "Peso integer NOT NULL, Fecha long NOT NULL);";

        String sqlCreaTabla2 = "CREATE TABLE IF NOT EXISTS Doctores (DNI integer PRIMARY KEY, "
                + "Nombre text NOT NULL, Apellidos text NOT NULL, Municipio text NOT NULL, CP integer NOT NULL,"
                + "Calle text NOT NULL, Numero integer NOT NULL, Piso integer NOT NULL, "
                + "Letra text NOT NULL, Telefono integer NOT NULL, Fecha long NOT NULL, "
                + "Especialidad text NOT NULL);";

        objSttmnt.execute(sqlCreaTabla);
        objSttmnt.execute(sqlCreaTabla2);

        objSttmnt.close();
        objCnxn.close();

    }

    private static void introducirDatosPacientes(String cadenaConexion) throws SQLException {

        Connection conn = DriverManager.getConnection(cadenaConexion, USER, PASS);
        String sql = "INSERT INTO Pacientes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";

        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, generarDNI());
        pstmt.setString(2, generarNombre());
        pstmt.setString(3, generarApellidos());
        pstmt.setString(4, generarMunicipio());
        pstmt.setInt(5, generarCP());
        pstmt.setString(6, generarCalle());
        pstmt.setInt(7, generarNumero());
        pstmt.setInt(8, generarPiso());
        pstmt.setString(9, String.valueOf(generarLetra()));
        pstmt.setInt(10, generarMovil());
        pstmt.setInt(11, generarAltura());
        pstmt.setInt(12, generarPeso());
        pstmt.setLong(13, generarFecha());
        pstmt.executeUpdate();

        pstmt.close();
        conn.close();

    }

    private static void introducirDatosDoctores(String cadenaConexion) throws SQLException {

        Connection conn = DriverManager.getConnection(cadenaConexion, USER, PASS);
        String sql = "INSERT INTO Doctores VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, generarDNI());
        pstmt.setString(2, generarNombre());
        pstmt.setString(3, generarApellidos());
        pstmt.setString(4, generarMunicipio());
        pstmt.setInt(5, generarCP());
        pstmt.setString(6, generarCalle());
        pstmt.setInt(7, generarNumero());
        pstmt.setInt(8, generarPiso());
        pstmt.setString(9, String.valueOf(generarLetra()));
        pstmt.setInt(10, generarMovil());
        pstmt.setLong(11, generarFecha());
        pstmt.setString(12, generarEspecialidad());
        pstmt.executeUpdate();

    }

    private static Random r = new Random();

    private static String generarNombre() {
        return nombres[r.nextInt(nombres.length - 1)];
    }

    private static String generarMunicipio() {
        return municipio[r.nextInt(municipio.length - 1)];
    }

    private static String generarCalle() {
        return calles[r.nextInt(calles.length - 1)];
    }

    private static String generarEspecialidad() {
        return especialidades[r.nextInt(especialidades.length - 1)];
    }

    public static int generarDNI() {
        return r.nextInt(10000000, 100000000);
    }

    public static int generarMovil() {
        return r.nextInt(600000000, 800000000);
    }

    public static int generarCP() {
        return r.nextInt(30000, 50001);
    }

    public static int generarNumero() {
        return r.nextInt(1, 100);
    }

    public static int generarPiso() {
        return r.nextInt(1, 14);
    }

    public static int generarAltura() {
        return r.nextInt(140, 200);
    }

    public static int generarPeso() {
        return r.nextInt(40, 120);
    }

    /**
     * genera un número que representa una fecha numérica a partir de una fecha
     * con formato estándar gracias a un conversor
     * https://www.epochconverter.com/ he usado una fecha de inicio 1/1/1940
     * -946727999 hasta el 1/1/2005 1104580801
     *
     * @return
     */
    public static long generarFecha() {
        return r.nextLong(-946771200, 1107215999);
    }

    public static char generarLetra() {
        return (char) r.nextInt(65, 91);
    }

    private static String generarApellidos() {
        return apellidos[r.nextInt(apellidos.length - 1)] + " " + apellidos[r.nextInt(apellidos.length - 1)];
    }

}
