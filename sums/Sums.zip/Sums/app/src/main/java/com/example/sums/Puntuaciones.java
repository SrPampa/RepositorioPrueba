package com.example.sums;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Puntuaciones extends AppCompatActivity {

    private ListView lista_score;
    private ArrayAdapter<String> adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntuaciones);

        List<String> lista_puntos = new ArrayList<String>();
        lista_score = (ListView) findViewById(R.id.lista_puntuaciones);



        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "db", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        Cursor consulta = db.rawQuery("SELECT * FROM score order by puntuacion desc", null);
        consulta.moveToFirst();
        int valores = consulta.getCount();
        while (valores > 0) {
          //  System.out.println("-------------------------" + consulta.getString(0) + consulta.getString(1) );
            lista_puntos.add(consulta.getString(1) +" "+ consulta.getString(0));
            consulta.moveToNext();
            valores--;

        }

        db.close();

        adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,lista_puntos);
        lista_score.setAdapter(adaptador);
    }

}