/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TCP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Cliente que recibe un mensaje, lo modifica y lo envía al servidor (se debe
 * ejecutar cada vez que se quiera conectar con el servidor que estará a la
 * espera todo el tiempo desde su primera ejecución)
 *
 * @author 6002291
 */
public class ClienteTCP {

    public static void main(String[] args) {

        //referencia a mi propia máquina
        final String HOST = "127.0.0.1";
        int puerto = 6666;

        DataInputStream dis;
        DataOutputStream dos;

        try {
            Socket sc = new Socket(HOST, puerto);

            dis = new DataInputStream(sc.getInputStream());
            dos = new DataOutputStream(sc.getOutputStream());

            String mensaje = dis.readUTF();
            dos.writeUTF(modMensaje(mensaje));

            System.out.println("Modificando y enviando: " + mensaje);

            sc.close();

        } catch (IOException ex) {
        }

    }

    /**
     * método para cambiar mayusculas por minúsculas y viceversa
     *
     * @param mensaje
     * @return
     */
    private static String modMensaje(String mensaje) {

        int cont = 0;
        String aux = "";

        for (int i = 0; i < mensaje.length(); i++) {

            if (mensaje.charAt(i) >= 'a' && mensaje.charAt(i) <= 'z') {
                aux += Character.toUpperCase(mensaje.charAt(i));
            } else if (mensaje.charAt(i) >= 'A' && mensaje.charAt(i) <= 'Z') {
                aux += Character.toLowerCase(mensaje.charAt(i));
            } else if (Character.isDigit(mensaje.charAt(i))) {
                aux += mensaje.charAt(i);
                cont++;
            } else {
                aux += mensaje.charAt(i);
            }
        }

        return aux;

    }
}
