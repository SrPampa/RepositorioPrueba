/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TCP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * servidor que solicite cadena de texto por teclado
 *
 * @author 6002291
 */
public class ServidorTCP {

    public static void main(String[] args) {

        Socket sc = null;
        ServerSocket servidor = null;

        int puerto = 6666;
        // creo datain/outStream como canales entre los programas
        DataInputStream dis;
        DataOutputStream dos;

        try {

            servidor = new ServerSocket(puerto);
            System.out.println("Servidor iniciado");

//dejo un bucle infinito para que el servidor siempre esté escuchando por si aparece una petición.
            while (true) {
                sc = servidor.accept(); //con accept se queda esperando aquí a recibir una petición

                System.out.println("Cliente conectado");
                dis = new DataInputStream(sc.getInputStream());
                dos = new DataOutputStream(sc.getOutputStream());
//envio mensaje por teclado después de conectar 
                dos.writeUTF(pedirMsjTeclado());

                String mensaje = dis.readUTF();
                System.out.println("Mensaje recibido del cliente: " + mensaje);
                //cierro el cliente
                sc.close();
                System.out.println("Cliente desconectado");
            }

        } catch (IOException ex) {
        }

    }

    private static String pedirMsjTeclado() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Escriba mensaje: ");
        return sc.nextLine();

    }

}
