/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author 6002291
 */
public class ClienteUPD {

    public static void main(String[] args) {

        int puerto_srv = 6666;
        byte[] buffer = new byte[1024];

        try {

            InetAddress direccionServidor = InetAddress.getByName("localhost"); //pongo localhost porque uso el propio equipo pero aquí pondría la dirección X

            DatagramSocket dtS = new DatagramSocket(); //no le asigno puerto porque es el cliente

            String mensaje = "Soy el cliente y me he conectado";
            buffer = mensaje.getBytes();
            DatagramPacket conectar = new DatagramPacket(buffer, buffer.length, direccionServidor, puerto_srv);
            dtS.send(conectar);

            DatagramPacket peticion = new DatagramPacket(buffer, buffer.length, direccionServidor, puerto_srv);
            System.out.println("Esperando los datos (mensaje) del servidor");
            dtS.receive(peticion);
            mensaje = new String(peticion.getData());

            mensaje = modMensaje(mensaje);
            buffer = mensaje.getBytes();

            DatagramPacket respuesta = new DatagramPacket(buffer, buffer.length, direccionServidor, puerto_srv);
            System.out.println("**envio el mensaje ya modificado**");
            dtS.send(respuesta);
            System.out.println("Cierro socket");
            dtS.close();

        } catch (SocketException ex) {
        } catch (UnknownHostException ex) {
        } catch (IOException ex) {
        }

    }

    private static String modMensaje(String mensaje) {

        int letra;
        int cont = 0;
        String aux = "";

        for (int i = 0; i < mensaje.length(); i++) {

            switch (mensaje.charAt(i)) {
                case 'z':
                    aux += 'a';
                    cont++;
                    break;
                case 'Z':
                    aux += 'A';
                    cont++;
                    break;
                case ' ':
                    aux += ' ';
                    cont++;
                    break;
                default:
                    letra = (int) mensaje.charAt(i);
                    aux += (char) (letra + 1);
                    cont++;
                    break;
            }
        }

        return aux;

    }
}
