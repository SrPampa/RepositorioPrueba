/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 6002291
 */
public class ServidorUPD {

    public static void main(String[] args) {

        int puerto = 6666;
        byte[] buffer = new byte[1024];

        try {
            System.out.println("Iniciado servidor UPD");
            DatagramSocket dtS = new DatagramSocket(puerto);
            while (true) { //le pongo un buvle infinito para que el servidor quede activo y no termine

                DatagramPacket objDP = new DatagramPacket(buffer, buffer.length);
                dtS.receive(objDP);
                System.out.println("Conectado a cliente");
                String mensaje = pedirMsjTeclado();

                int puertoCliente = objDP.getPort();
                InetAddress direccion = objDP.getAddress();
                buffer = mensaje.getBytes();
                DatagramPacket envioCliente = new DatagramPacket(buffer, buffer.length, direccion, puertoCliente);
                System.out.println("Envio info cliente");
                dtS.send(envioCliente);

                objDP = new DatagramPacket(buffer, buffer.length);
                dtS.receive(objDP);
                mensaje = new String(objDP.getData());
                System.out.println("Mensaje codificado recibido del cliente: \n"+mensaje);

            }

        } catch (SocketException ex) {
            ex.getStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(ServidorUPD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static String pedirMsjTeclado() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Escriba mensaje: ");
        return sc.nextLine();

    }

}
