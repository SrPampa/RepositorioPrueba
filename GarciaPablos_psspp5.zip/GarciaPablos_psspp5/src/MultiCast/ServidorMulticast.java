/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MultiCast;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Scanner;

/**
 * Realiza los programas ServidorMultiCast y ClienteMultiCast, de modo que el
 * programa servidor recogo cadenas por teclado, después de recoger la cadena la
 * envía a todos los clientes multicast que se encuentre en la ip
 * 224.225.226.227 yn el puerto 123456. Los clientes multicast mostrarán la
 * información quen han recibido. Este proceso se repetirá hasta que la cadena
 * introducida sea *. Cuando el programa recibe por teclado la cadena *,
 * entonces ambos programas finalizan su funcionamiento de forma correcta.
 *
 * @author 6002291
 */
public class ServidorMulticast {

    public static void main(String[] args) {
        int puerto = 12345;
        byte[] buffer = new byte[1024];

        try {
            InetAddress ip = InetAddress.getByName("224.225.226.227");

            Scanner sc = new Scanner(System.in);

            MulticastSocket socket = new MulticastSocket();
            System.out.println("Servidor iniciado");
            String mensaje;
            do {
                System.out.println("Escriba cadena para enviar o introduzca * para cerrar: ");
                mensaje = sc.nextLine();
                buffer = mensaje.getBytes();
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length, ip, puerto);
                socket.send(paquete);
            } while (!mensaje.equals("*"));
            System.out.println("Cerrando correctamente");
            socket.close();
        } catch (IOException ex) {
        }
    }

}
