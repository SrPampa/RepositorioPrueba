/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MultiCast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

/**
 *
 * @author 6002291
 */
public class ClienteMulticast {

    public static void main(String[] args) {
        int puerto = 12345; //de un número menos porque son el 6 se sale de rango
        byte[] buffer = new byte[1024];
        try {
            InetAddress grupo = InetAddress.getByName("224.225.226.227");

            MulticastSocket socket = new MulticastSocket(puerto);
            socket.joinGroup(grupo); //al parecer esto está deprecated pero funciona correctamente

            while (true) {
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
                socket.receive(paquete);
                String mensaje = new String(paquete.getData(), 0, paquete.getLength());
                System.out.println(mensaje);
                if (mensaje.equals("*")) {
                    System.out.println("Cerrando correctamente");
                    break;
                }
            }

            socket.leaveGroup(grupo);
            socket.close();
        } catch (IOException ex) {
        }
    }

}
