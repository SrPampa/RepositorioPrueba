/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infoSockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Admite en el puerto 6666 una conexión desde un cliente / despues de realizar
 * la conexión entre ambos muestran por pantalla la info de todos los obj de la
 * clase Socket y ServerSocket implicados en la TCP
 *
 * @author 6002291
 */
public class ServidorInfoTCP {

    public static void main(String[] args) {

        Socket sc = null;
        ServerSocket servidor = null;

        int puerto = 6666;

        try {

            servidor = new ServerSocket(puerto);
            //bucle infinito para que el servidor siempre esté escuchando
            while (true) {
                sc = servidor.accept();

                System.out.println("------------Datos del servidor-------------");

                System.out.println("Localport: " + sc.getLocalPort());
                System.out.println("Port: " + sc.getPort());
                System.out.println(servidor.toString());
                System.out.println("bufferedSize: " + servidor.getReceiveBufferSize());
                System.out.println("bound: " + servidor.isBound());
                System.out.println("isClose: " + servidor.isClosed());
                System.out.println("Dirección local: " + sc.getLocalAddress().getHostAddress());
                System.out.println("Dirección remota: " + sc.getInetAddress().getHostAddress());
                System.out.println("Dirección remota srv: " + servidor.getInetAddress().getHostAddress());

                System.out.println("-------------------------------------------");
            }

        } catch (IOException ex) {
        }

    }

}
