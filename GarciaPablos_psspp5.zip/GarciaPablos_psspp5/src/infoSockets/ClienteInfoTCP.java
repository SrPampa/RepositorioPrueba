/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infoSockets;

import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author 6002291
 */
public class ClienteInfoTCP {

    public static void main(String[] args) {

        //referencia a mi propia máquina
        final String HOST = "127.0.0.1";
        int puerto = 6666;

        try {
            Socket sc = new Socket(HOST, puerto);

            System.out.println("------------Datos del cliente-------------");
            System.out.println("Localport: " + sc.getLocalPort());
            System.out.println("Port: " + sc.getPort());
            System.out.println(sc.toString());
            System.out.println("isConnected: " + sc.isConnected());
            System.out.println("Dirección local: " + sc.getLocalAddress().getHostAddress());
            System.out.println("Dirección remota: " + sc.getInetAddress().getHostAddress());

            System.out.println("-------------------------------------------");

            sc.close();

        } catch (IOException ex) {
        }

    }

}
