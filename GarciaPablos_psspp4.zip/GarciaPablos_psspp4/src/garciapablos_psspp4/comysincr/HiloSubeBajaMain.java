/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.comysincr;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 6002291
 */
public class HiloSubeBajaMain {

    public static void main(String[] args) {

        Testigo t = new Testigo(0);
        HiloSube hup = new HiloSube(t, "HiloSube");
        HiloBaja hdown = new HiloBaja(t, "HiloBaja");
        
        hup.start();

        hdown.start();
        
        try {
            hdown.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(HiloSubeBajaMain.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("************"+t.muestra());
               
              
        
    }

}
