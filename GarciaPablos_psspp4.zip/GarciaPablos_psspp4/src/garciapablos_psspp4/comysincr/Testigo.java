/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.comysincr;

/**
 *
 * @author 6002291
 */
public class Testigo {
    
    private int testigo;

    public Testigo(int testigo) {
        this.testigo = testigo;
    }

    public void sube(){
        testigo++;
    }
    public void baja(){
        testigo--;
    }
    public int muestra(){
        return testigo;
    }
    
}
