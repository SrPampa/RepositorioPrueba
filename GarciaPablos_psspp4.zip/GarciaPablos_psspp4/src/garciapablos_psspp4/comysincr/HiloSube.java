/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.comysincr;

/**
 *
 * @author 6002291
 */
public class HiloSube extends Thread{
    
    private Testigo t;

    public HiloSube(Testigo t, String name) {
        super(name);
        this.t = t;
    }
    
     public void run() {

        for (int i = 0; i < 400; i++) {
            t.sube();
//            try {
//                sleep(100); //se para un segundo 
//            } catch (InterruptedException e) {
//            }
            System.out.println(getName()+" - " +t.muestra());
        }
        System.out.println("Fin del bucle de: " + getName());
    }
}
