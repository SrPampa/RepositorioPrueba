/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.comysincr;

/**
 *
 * @author 6002291
 */
public class ObjCompNoBloqueoSeguroMain {

    public static void main(String[] args) {

        ObjComp objComp = new ObjComp();
        ObjCompHilo h1 = new ObjCompHilo(objComp, "1");
        ObjCompHilo h2 = new ObjCompHilo(objComp, "2");

        h1.start();
        h2.start();

    }
}
