/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.comysincr;

/**
 *
 * @author 6002291
 */
public class ObjCompHilo extends Thread {

    private ObjComp objeto_compartido;
    private String cadena;

    public ObjCompHilo(ObjComp objeto_compartido, String cadena) {
        this.objeto_compartido = objeto_compartido;
        this.cadena = cadena;
    }

    public void run() {

        synchronized (objeto_compartido) {

            for (int i = 0; i < 10; i++) {
                objeto_compartido.muestraCad(cadena);
                objeto_compartido.notify();
                try {
                    objeto_compartido.wait();
                } catch (InterruptedException e) {
                }
            }
            objeto_compartido.notifyAll();
        }
        System.out.println("Hilo"+cadena+" finaliza");
    }

}
