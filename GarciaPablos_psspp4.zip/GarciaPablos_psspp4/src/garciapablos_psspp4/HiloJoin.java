/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4;

import garciapablos_psspp4.ejemplos.*;

/**
 *
 * @author 6002291
 */
public class HiloJoin extends Thread {


    public HiloJoin(String nombre) {
        super(nombre);
    }

    public void run() {

        for (int i = 0; i < 5; i++) {
            System.out.println(getName()+" paso: "+ (i+1));
            try {
                sleep(1000); //se para un segundo 
            } catch (InterruptedException e) {
            }
        }
        System.out.println("Fin del bucle de: " + getName());
    }
}
