/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4;

import static java.lang.Thread.sleep;

/**
 * al ejecutar el programa se lancen cuatro hilos de forma que el inicio del
 * segundo hilo se produzca a partir de la finalización del primero, el inicio
 * del tercer hilo a partir de los 2 segundos de iniciarse el segundo, el inicio
 * del cuarto hilo se produzca a partir de los 3 segundos de iniciarse el
 * tercero. El código que ejecutarán los hilos es un bucle de 5 pasos, cada paso
 * del bucle de un segundo de duración y en cada paso del bucle se indicará por
 * pantalla la información del hilo y del paso.
 *
 * @author 6002291
 */
public class PruebaHiloJoin {

    public static void main(String[] args) {

        HiloJoin h1 = new HiloJoin("Hilo1");
        HiloJoin h2 = new HiloJoin("Hilo2");
        HiloJoin h3 = new HiloJoin("Hilo3");
        HiloJoin h4 = new HiloJoin("Hilo4");

        h1.start();
        try {
            h1.join(); //con el join espero a que acabe el proceso
            System.out.println("Finaliza Hilo1");
        } catch (InterruptedException e) {
        }
        h2.start(); //inicio el segundo hilo al terminar el primero
        try {
            h2.sleep(2000); // espero dos segundos
            System.out.println("Finaliza Hilo2");
        } catch (InterruptedException e) {
        }

        h3.start(); //se inicia a los dos segundos de iniciarse el h2
        try {
            h3.sleep(3000); // espero tres segundos
            System.out.println("Finaliza Hilo3");
        } catch (InterruptedException e) {
        }
        h4.start();//se inicia a los tres segundos de iniciarse el h3
        System.out.println("Fin ejecucion proceso main");
    }

}
