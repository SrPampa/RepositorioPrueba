/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4;

import garciapablos_psspp4.comysincr.HiloBaja;
import garciapablos_psspp4.comysincr.HiloSube;
import garciapablos_psspp4.comysincr.Testigo;


/**
 *
 * @author 6002291
 */
public class SubebajaTestigoMain {

    public static void main(String[] args) {

        Testigo t = new Testigo(10); // inicio con el valor entero 10
        HiloSube hup = new HiloSube(t, "HiloSube");
        HiloBaja hdown = new HiloBaja(t, "HiloBaja");

        synchronized (t) { //uso synchronized con el objeto Testigo y dentro dejo los hilos que contienen los métodos para controlar todos los métodos de t
            hup.start();
            hdown.start();
        }

        try {
            hdown.join(); //uso join para esperar a que terminen ambos 
            hup.join();   //procesos antes de mostrar el resultado final
        } catch (InterruptedException ex) {
        }
        System.out.println("Resultado final: " + t.muestra()); //si la sincronización está bien utilizada el resultado siempre debería ser el inicial (10)
    }
}
