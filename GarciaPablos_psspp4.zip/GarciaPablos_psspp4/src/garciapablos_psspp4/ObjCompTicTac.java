/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4;

import garciapablos_psspp4.comysincr.*;

/**
 *
 * @author 6002291
 */
public class ObjCompTicTac extends Thread { //reciclado del ejemplo

    private ObjComp objeto_compartido;
    private String cadena;

    public ObjCompTicTac(ObjComp objeto_compartido, String cadena) {
        this.objeto_compartido = objeto_compartido;
        this.cadena = cadena;
    }

    public void run() {

        synchronized (objeto_compartido) {

            while (true) {
                objeto_compartido.muestraCad(cadena);
                objeto_compartido.notify();
                try {
                    Thread.sleep(1000); //un segundo para que lo veamos por pantalla
                    objeto_compartido.wait();
                } catch (InterruptedException e) {
                }
            }
        }
    }

}
