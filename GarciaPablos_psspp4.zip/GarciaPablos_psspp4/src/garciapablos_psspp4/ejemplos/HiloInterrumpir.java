/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloInterrumpir extends Thread {

    public void run() {

        try {
            while (!isInterrupted()) {
                System.out.println("mensaje hilo");
                Thread.sleep(111);
            }
        } catch (InterruptedException IntExc) {
            System.out.println("Ocurrió una excepción y el hilo terminará");
        }
        System.out.println("Hilo termina");
    }

    public void interrumpir() {
        interrupt();
    }

}
