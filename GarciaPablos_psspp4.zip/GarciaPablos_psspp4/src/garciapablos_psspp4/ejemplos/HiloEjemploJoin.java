/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloEjemploJoin extends Thread {

    private int numero;

    public HiloEjemploJoin(String nombre, int numero) {
        super(nombre);
        this.numero = numero;
    }

    public void run() {

        for (int i = 0; i < numero; i++) {
            System.out.println("Soy el hilo " + getName());
            try {
                sleep(100);
            } catch (InterruptedException e) {
            }
        }
        System.out.println("Fin del bucle del hilo: " + getName());
    }
}
