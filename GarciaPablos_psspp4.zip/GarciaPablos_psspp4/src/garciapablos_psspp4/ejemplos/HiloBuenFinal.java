/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloBuenFinal extends Thread {

    private boolean finH = false;

    public void finHi1o() {
        finH = true;
    }

    public void run() {
        int cont = 0;
        while (!finH) {
            cont++;
            System.out.println("\tmensaje " + cont + " en el hilo");
        }
    }
}
