/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloEjemploJoinMain {

    public static void main(String[] args) {

        HiloEjemploJoin hej1 = new HiloEjemploJoin("Hilo1", 2);
        HiloEjemploJoin hej2 = new HiloEjemploJoin("Hilo2", 3);
        HiloEjemploJoin hej3 = new HiloEjemploJoin("Hilo3", 5);
        hej1.start();
        try {
            hej1.join();
            System.out.println("Se ejecuta después de finalizar Hilo1");
        } catch (InterruptedException e) {
        }
        hej2.start();
        try {
            hej2.join();
            System.out.println("Se ejecuta después de finalizar Hilo2");
        } catch (InterruptedException e) {
        }

        hej3.start();
        System.out.println("Fin del programa main");
    }

}
