/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 * Uso esta clase creada por defecto al crear el proyecto como main de
 * HiloBuenFinal
 *
 * @author 6002291 // este es mi numero de empleado de viewnext (si uso el
 * portatil de la empresa aparecerá eso como autor en vez de "Usuario" como
 * aparece en mi PC que funciona mal)
 */
public class GarciaPablos_psspp4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HiloBuenFinal hbf = new HiloBuenFinal();
        hbf.start();
        while (true) {
            System.out.println("mensaje en main");

            if ((int) 10 * Math.random() == 0) {
                hbf.finHi1o();
                break;
            }
        }
    }
}
