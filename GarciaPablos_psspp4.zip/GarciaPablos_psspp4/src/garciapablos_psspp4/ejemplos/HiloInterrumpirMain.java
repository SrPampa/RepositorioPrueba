/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloInterrumpirMain {

    public static void main(String[] args) {

        HiloInterrumpir hInt = new HiloInterrumpir();
        hInt.start();

        while (true) {
            System.out.println("en main");
            if ((int) 10 * Math.random() == 0) {
                hInt.interrumpir();
                break;
            }
        }

    }

}
