/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4.ejemplos;

/**
 *
 * @author 6002291
 */
public class HiloBuenParar extends Thread {

    private PeticionParar petParar = new PeticionParar();

    public void Parar() {
        petParar.set(true);
    }

    public void Reanudar() {
        petParar.set(false);
    }

    public void run() {
        /*
        aqui habria que añadir la condicion y las sentencias
      
        try {

            while (condicion) {
                sencencias;
                petsusp.esperar();
                sentencias;
            }

        } catch (InterruptedException IntExcept) {
        }
         */
    }

}
