/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garciapablos_psspp4;

import garciapablos_psspp4.comysincr.ObjComp;
import garciapablos_psspp4.comysincr.ObjCompHilo;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * a partir del ejemplo TicTac, cambiando Io necesaruo para que en el programa
 * se produzca la sincronización temporal entre los dos hilos. El resultado será
 * que la ejecución va repitiendo Tic—Tac—Tic—Tac—....
 *
 * @author 6002291
 */
public class TicTacSync {

    public static void main(String[] args) {

        ObjComp obj = new ObjComp(); //uso la misma clase que usé para el ejemplo (package comysincr)

        Thread tic = new ObjCompTicTac(obj, "Tic");
        Thread tac = new ObjCompTicTac(obj, "Tac");
        Thread toc = new ObjCompTicTac(obj, "Toc");

        tic.start();
        tac.start();
        toc.start();

    }

}
